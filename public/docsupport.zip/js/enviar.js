  function enviar(seleccion)
  {
    if(seleccion>0)
    {
      document.formulario1.submit() ;
    }
  }


  function enviar2(seleccion2)
  {
    if(seleccion2>0)
    {
      document.formulario2.submit() ;
    }
  }


   function enviar3(seleccion3)
  {
    if(seleccion3>0)
    {
      document.formulario3.submit() ;
    }
  }